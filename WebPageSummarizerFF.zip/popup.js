// popup.js

document.addEventListener('DOMContentLoaded', function() {
  const summarizeBtn = document.getElementById('summarizeBtn');
  const loadingDiv = document.getElementById('loading');
  const summaryDiv = document.getElementById('summary');
  const copyBtn = document.getElementById('copyBtn');

  summarizeBtn.addEventListener('click', function() {
    loadingDiv.style.display = 'block';
    summaryDiv.textContent = '';
    copyBtn.style.display = 'none';

    browser.tabs.query({active: true, currentWindow: true}, function(tabs) {
      browser.tabs.sendMessage(tabs[0].id, {action: 'getContent'}, function(response) {
        if (response && response.content) {
          browser.runtime.sendMessage({action: 'summarize', content: response.content}, function(result) {
            loadingDiv.style.display = 'none';
            if (result.summary) {
              summaryDiv.textContent = result.summary;
              copyBtn.style.display = 'block';
            } else if (result.error) {
              summaryDiv.textContent = 'Error: ' + result.error;
            }
          });
        } else {
          loadingDiv.style.display = 'none';
          summaryDiv.textContent = 'Error: Unable to get page content';
        }
      });
    });
  });

  copyBtn.addEventListener('click', function() {
    navigator.clipboard.writeText(summaryDiv.textContent).then(function() {
      const originalText = copyBtn.textContent;
      copyBtn.textContent = 'Copied!';
      setTimeout(function() {
        copyBtn.textContent = originalText;
      }, 2000);
    }).catch(function(err) {
      console.error('Failed to copy text: ', err);
    });
  });
});